from helper import Jacobi

print("Question 7: ")
print ("Jacobi notation of 1983 and 2027 is:", Jacobi(1983, 2017))
print ("Jacobi notation of 873 and 2029 is:", Jacobi(873, 2019))
print ("Jacobi notation of 474993 and 1003001 is:", Jacobi(474993, 1003001), "\n")
